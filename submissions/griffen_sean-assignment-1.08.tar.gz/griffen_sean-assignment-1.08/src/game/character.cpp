/******** include std libs ********/
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>

/******* include custom libs ******/
#include "./classdef/character.h"
#include "./utils/movement.h"

/*********** global vars **********/


/***** constructor definitions *****/
Character::Character() {
	
	id 			= 0;
	name 		= "";
	description = "";
	symbol 		= '\0';
	
	speed 		= 0;
	hp 			= 1;
	damage 		= Dice();
	color 		= std::vector<uint8_t>();
	items		= std::vector<Item*>();
}
Character::Character(const Character &rhs) {
	
	id 			= rhs.id;
	name 		= rhs.name;
	description = rhs.description;
	symbol 		= rhs.symbol;
	
	speed 		= rhs.speed;
	hp 			= rhs.hp;
	damage 		= rhs.damage;
	color 		= rhs.color;
	items		= rhs.items;
}
Character::Character(uint32_t character_id, Coordinate character_loc, uint16_t character_hp, Dice character_damage, uint8_t character_speed) : Character() {
	
	location		= Coordinate(character_loc);
	prev_location 	= Coordinate(character_loc);
	id 				= character_id;
	symbol 			= '\0';
	
	speed 			= character_speed;
	hp 				= character_hp;
	damage 			= character_damage;
}
Character::Character(std::string character_name, std::string character_description, char character_symbol, std::vector<uint8_t> character_color, uint32_t character_id, Coordinate character_loc, uint16_t character_hp, Dice character_damage, uint8_t character_speed) : Character(character_id, character_loc, character_hp, character_damage, character_speed) {
	
	name.assign(character_name);
	description.assign(character_description);
	
	symbol 		= character_symbol;
	color 		= character_color;
}

PC::PC() : Character() {
	
	num_kills = 0;
}
PC::PC(const PC &rhs) : Character(rhs) {
	
	num_kills = rhs.num_kills;
}
PC::PC(Coordinate pc_loc, uint16_t pc_hp, Dice pc_damage, uint8_t pc_speed) : Character(0, pc_loc, pc_hp, pc_damage, pc_speed) { 
	
	num_kills = 0;
}
PC::PC(std::string pc_name, std::string pc_description, char pc_symbol, std::vector<uint8_t> pc_color, Coordinate pc_loc, uint16_t pc_hp, Dice pc_damage, uint8_t pc_speed) : Character(pc_name, pc_description, pc_symbol, pc_color, 0, pc_loc, pc_hp, pc_damage, pc_speed) {
	
	num_kills = 0;
}

NPC::NPC() : Character() {
	
	type 	= 0x00;
	rarity 	= 1;
}
NPC::NPC(const NPC &rhs) : Character(rhs) {
	
	type = rhs.type;
	rarity = rhs.rarity;
}
NPC::NPC(uint32_t npc_id, Coordinate npc_loc, uint16_t npc_hp, uint16_t npc_type, Dice npc_damage, uint8_t npc_speed) : Character(npc_id, npc_loc, npc_hp, npc_damage, npc_speed) { 
	
	type 	= npc_type;
	rarity 	= 1;
}
NPC::NPC(uint8_t npc_rarity, std::string npc_name, std::string npc_description, char npc_symbol, std::vector<uint8_t> npc_color, uint32_t npc_id, Coordinate npc_loc, uint16_t npc_hp, uint16_t npc_type, Dice npc_damage, uint8_t npc_speed) : Character(npc_name, npc_description, npc_symbol, npc_color, npc_id, npc_loc, npc_hp, npc_damage, npc_speed) {
	
	type 	= npc_type;
	rarity 	= npc_rarity;
}

/****** function definitions ******/
void Character::draw(uint8_t print_y, uint8_t print_x, int print_fill) {
	
	attron(COLOR_PAIR(color[0]));
	
	if (print_fill) { mvprintw(print_y, print_x, "%2c", symbol); } 
	else 			{ mvaddch(print_y, print_x, symbol); }
	
	attroff(COLOR_PAIR(color[0]));
	
	return;
}