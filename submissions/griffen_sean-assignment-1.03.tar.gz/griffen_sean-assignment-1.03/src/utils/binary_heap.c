/******** include std libs ********/
#include <stdlib.h>
#include <stdio.h>

/******* include custom libs ******/
#include "binary_heap.h"

/********** definitions **********/



/*********** global vars **********/


/****** function definitions ******/
