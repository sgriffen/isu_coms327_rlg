#ifndef BINARY_HEAP_H
#define BINARY_HEAP_H

#include <stdint.h>

#include "../coordinate.h"

/********** definitions **********/


/******* enums declarations *******/



/******* struct declarations ******/
typedef struct {
	
	
} HeapNode;

typedef struct {
	
	
} Heap;

/****** function declarations *****/



#endif /* BINARY_HEAP_H */