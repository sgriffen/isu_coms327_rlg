#ifndef ROUGE_H
#define ROUGE_H

#include "src/dungeon.h"
#include "src/utils/file_utils.h"
#include "src/utils/pathfinder.h"

/********** definitions **********/



/******* enums declarations *******/

/******* struct declarations ******/
typedef struct {
	
	uint8_t print_type;
	uint8_t print_color;
	uint8_t print_hardness;
	uint8_t print_weight_ntunneling;
	uint8_t print_weight_tunneling;
	uint8_t print_traversal_cost;
	
	uint8_t file_load;
	char *load_dir;
	uint8_t file_save;
	char *save_dir;
} RunArgs;

/****** function definitions ******/
void args_parse(int argc, char *argv[], RunArgs *run_args);

void rouge_init(Dungeon *dungeon, char *argv[], RunArgs run_args);

void rouge_run(Dungeon *dungeon, RunArgs run_args);

void rouge_clean(Dungeon *dungeon, char *argv[], RunArgs run_args);

int fread_dungeon(Dungeon *dungeon, char* f_name);

int fwrite_dungeon(Dungeon dungeon, char* f_name);


#endif /* ROUGE_H */