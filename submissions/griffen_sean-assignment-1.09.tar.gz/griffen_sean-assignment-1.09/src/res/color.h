#ifndef COLOR_H
#define COLOR_H

#define NUM_COLORS 8
#define PAIR_BLACK 0
#define PAIR_WHITE 1
#define PAIR_RED 2
#define PAIR_GREEN 3
#define PAIR_BLUE 4
#define PAIR_CYAN 5
#define PAIR_YELLOW 6
#define PAIR_MAGENTA 7

#endif /* COLOR_H */