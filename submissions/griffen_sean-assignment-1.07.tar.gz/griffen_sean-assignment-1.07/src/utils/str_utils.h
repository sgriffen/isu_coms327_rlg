#include <string>
#include <vector>

std::vector<std::string> strsplit(std::string tosplit, std::string delimiter);