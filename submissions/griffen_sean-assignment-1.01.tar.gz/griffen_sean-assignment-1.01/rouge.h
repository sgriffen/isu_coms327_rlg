#include "level.h"

/********** definitions **********/
#define ARGS_LENGTH 1
#define ARGS_DEPTH 1

/******* enums declarations *******/


/******* struct declarations ******/


/****** function declarations *****/
void args_parse(int argc, char *argv[], int (*run_args)[ARGS_LENGTH][ARGS_DEPTH]);